#include "sub.h"

void Sub::UpdateValue(){
    value_=input1->value()-input2->value();
}