#include "add.h"

void Add::UpdateValue(){
    value_=input1->value()+input2->value();
}