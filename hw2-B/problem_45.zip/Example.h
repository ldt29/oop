#ifndef __EXAMPLE__
#define __EXAMPLE__
	
class Example {
		
private:
	
	// (1)
			
public:
	
	Example(int data);
	void getData();
	~Example();

};
		
#endif