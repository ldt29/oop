#include <iostream>
#include "Example.h"

using namespace std;

	// (2)

Example::Example(int data) {
	// (3)
}

void Example::getData() {
	// (4)
}

Example::~Example() {
	// (5)
}